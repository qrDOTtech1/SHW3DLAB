# Logique de commande DSDM - DaVinBot V2

## Cinematique du differentiel

Differentiel planetaire : solaire Zs=27, satellites Zp=12, couronne Zr=51 (module 1.0).

```
w_sortie = (Zs * w_solaire + Zr * w_couronne) / (Zs + Zr)
w_couronne = w_M1 / i_c        avec i_c = 58.846  (etage 45/26 x cycloidal 34:1)
w_solaire  = -w_M2 / i_s       avec i_s = 1.000  (etage 32/32)
=> w_sortie = w_M1 / 90.000  +  w_M2 / 2.889   (signes selon cablage)
```

## Rapports virtuels

| Mode | M1 (couple) | M2 (vitesse) | Verrou M2 | Rapport | Couple sortie | Vitesse sortie |
|---|---|---|---|---|---|---|
| J2 Force | tourne | bloque | ENGAGE | 90.0:1 | 21.79 N.m | 40.0 deg/s |
| J2 Vitesse | maintien | tourne | libre | 2.89:1 | 0.87 N.m | 1246.1 deg/s |
| J2 Hybride | tourne | tourne | libre | somme | 0.87 N.m | 1286.1 deg/s |
| J3 Force | tourne | bloque | ENGAGE | 90.0:1 | 21.79 N.m | 40.0 deg/s |
| J3 Vitesse | maintien | tourne | libre | 2.89:1 | 0.87 N.m | 1246.1 deg/s |
| J3 Hybride | tourne | tourne | libre | somme | 0.87 N.m | 1286.1 deg/s |

## Point physique critique (verifie par le generateur)

Dans un differentiel, le couple de sortie est TOUJOURS partage : il faut que les deux
entrees le contiennent. Couple de sortie maxi = min(T_M1 x i1, T_M2 x i2) tant que M2
n'est tenu qu'electroniquement. D'ou le **cliquet mecanique** sur la roue solaire :
verrou engage, l'effort passe par le pivot et le mode Force delivre le couple du cycloidal.

- J2 : mode Vitesse autorise tant que le couple gravitaire < 0.87 N.m, soit un bras incline de moins de **1.6 deg** par rapport a la verticale en charge maxi (couple requis horizontal : 12.29 N.m).
- J3 : mode Vitesse autorise tant que le couple gravitaire < 0.87 N.m, soit un bras incline de moins de **3.6 deg** par rapport a la verticale en charge maxi (couple requis horizontal : 13.83 N.m).

## Sequence ESP32 (pseudo-code)

```cpp
enum Gear { FORCE, VITESSE, HYBRIDE };

void setGear(Axis &ax, Gear g) {
  if (g == FORCE) {
    ax.m2.holdStrict();            // MKS SERVO42C : maintien, courant max
    ax.lockServo.write(LOCK_ON);   // MG90S cliquet : 0 deg -> engage
    waitMs(120);                   // temps de basculement du cliquet
    ax.m2.release();               // l'effort passe dans le cliquet
  } else {
    float tg = gravityTorque(ax);  // modele statique (masses du generateur)
    if (g != HYBRIDE && tg > ax.T_m2_max) g = HYBRIDE; // M2 seul trop faible
    ax.m2.holdStrict();
    ax.lockServo.write(LOCK_OFF);  // 30 deg -> cliquet degage
    waitMs(120);
  }
  ax.gear = g;
}

// consigne de vitesse articulaire w (deg/s) -> vitesses moteurs
void drive(Axis &ax, float w) {
  switch (ax.gear) {
    case FORCE:   ax.m1.speed(w * 90.000); ax.m2.speed(0); break;
    case VITESSE: ax.m1.hold();              ax.m2.speed(w * 2.889); break;
    case HYBRIDE: {
      // repartition : M1 fournit la part lente (couple), M2 le complement rapide
      float w1 = constrain(w, -W1_MAX, W1_MAX);   // W1_MAX = rpm_max*6/90.000
      float w2 = w - w1;
      ax.m1.speed(w1 * 90.000); ax.m2.speed(w2 * 2.889); break;
    }
  }
}
```

Transitions : ne changer de rapport qu'a vitesse articulaire nulle ; en mode Force, verifier
l'engagement du cliquet par la derive de position de M2 (encodeur du MKS) < 1 pas.